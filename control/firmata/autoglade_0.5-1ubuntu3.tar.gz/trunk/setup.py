#!/usr/bin/env python
from distutils.core import setup

data_files = None

setup (name = "autoglade",
    description="Autoglade automagic GUI builder",
    version="0.4",
    author="Diego Torres Milano",
    author_email="diego@codtech.com",
    url="http://autoglade.sourceforge.net/",
    packages=['autoglade'],
    license="GPL",
    long_description="""
		Autoglade automagic application generation using Glade
 		Autoglade could be run directly or can be used from other modules to
 		obtain automagic application generation from the Glade GUI interface
 		definition.
 		"""
)
