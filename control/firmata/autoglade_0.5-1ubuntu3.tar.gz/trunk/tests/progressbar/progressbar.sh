#! /bin/bash



for n in 10 20 25 35 45 60 75 88 93 100
do
	echo $n
	sleep 1
done | ${AUTOGLADE:-autoglade} ${0%.sh}.glade
