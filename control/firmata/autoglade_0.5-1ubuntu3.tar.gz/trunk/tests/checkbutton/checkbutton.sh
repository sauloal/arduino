#! /bin/sh
# $Id$

# for example:
export checkbutton1='True'
export checkbutton2='False'
#export checkbutton3='1'

${AUTOGLADE:-autoglade} ${0%.sh}.glade
