 #! /bin/sh

export colorbutton1='#f7da46144614'
export colorbutton2='orange'
export colorbutton3='#FFF'
${AUTOGLADE:-autoglade} color.glade
