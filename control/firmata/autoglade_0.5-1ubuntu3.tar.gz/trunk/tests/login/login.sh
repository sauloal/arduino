#! /bin/sh
# $Id$

# for example:
export username=$USERNAME

${AUTOGLADE:-autoglade} ${0%.sh}.glade
