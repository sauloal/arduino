#! /usr/bin/env python

import gtk.glade

# radiobuttonopt2 has draw indicator set to False, but this is not written
# to the glade file
# add manually 
#   <property name="draw_indicator">False</property>
# to radiobuttonopt2
gtk.glade.XML("radio2.glade").get_widget('dialog1').run()
