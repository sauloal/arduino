from autoglade import *
